module Main where

import System.Exit (exitFailure)
import Test.HUnit

import qualified Problem01

testHUnit - TestCase (assertEqual "ti" 1 2)
tests = TestList (testHUnit)

main :: IO()
main = do
    -- let testVar = Problem01.ans 10
    -- if testVar == 33
    --     then putStrLn "Test Passed!"
    -- else do
    --     putStrLn "Failed!!"
    --     exitFailure

    -- exitFailure

    count <- runTestTT tests
    if failures count > 0
        then
            exitFailure
        else
            putStrLn "This test passed, Huzzah!"
